package com.nova.client.mixin;

import com.nova.client.rotation.RotationManager;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Makes W walk towards the locked target even though the camera looks somewhere else. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Redirect(method = "updateVelocity", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getYaw()F"))
    private float nova$moveYaw(Entity instance) {
        if (instance instanceof ClientPlayerEntity && RotationManager.isMoveFixActive()) {
            return RotationManager.getMoveYaw();
        }
        return instance.getYaw();
    }

    @ModifyVariable(method = "updateVelocity", at = @At("HEAD"), argsOnly = true)
    private Vec3d nova$forwardOnly(Vec3d input) {
        if ((Object) this instanceof ClientPlayerEntity
                && RotationManager.isMoveFixActive() && RotationManager.isForwardOnly()) {
            return new Vec3d(0.0, input.y, Math.max(0.0, input.z));
        }
        return input;
    }
}
