package com.nova.client.module.impl;

import com.nova.client.mixin.LivingEntityInvoker;
import com.nova.client.module.Category;
import com.nova.client.module.ModeSetting;
import com.nova.client.module.Module;
import com.nova.client.module.NumberSetting;
import com.nova.client.rotation.RotationManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

/**
 * Faster walking. Speed is in blocks per tick (normal sprinting is about 0.28).
 *
 * Strafe - holds that speed in the direction your movement keys point, on the ground and in the air.
 * BHop   - jumps by itself while you move and keeps the speed up in the air.
 */
public final class SpeedModule extends Module {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public final ModeSetting mode = new ModeSetting("Mode", "Strafe", "Strafe", "BHop");
    public final NumberSetting speed = new NumberSetting("Speed", 0.32, 0.10, 1.00, 0.01);

    public SpeedModule() {
        super("Speed", "Faster movement.", Category.MOVE);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (p.isTouchingWater() || p.isInLava() || p.isClimbing() || p.hasVehicle() || p.getAbilities().flying) return;
        // never fight an elytra flight (ElytraHelper): airborne with an elytra on = leave the velocity alone
        if (!p.isOnGround() && p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) return;

        int forward = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        int side = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        if (forward == 0 && side == 0) return;

        // same direction math as vanilla; follows Aura's move-to-target direction when it is active
        float yaw = RotationManager.isMoveFixActive() ? RotationManager.getMoveYaw() : p.getYaw();
        double sin = Math.sin(Math.toRadians(yaw));
        double cos = Math.cos(Math.toRadians(yaw));
        double dx = side * cos - forward * sin;
        double dz = forward * cos + side * sin;
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length < 1.0E-6) return;
        dx /= length;
        dz /= length;

        double target = speed.getValue();
        Vec3d velocity = p.getVelocity();

        if (mode.is("BHop")) {
            if (p.isOnGround()) {
                ((LivingEntityInvoker) p).nova$invokeJump();
                velocity = p.getVelocity();
            } else {
                double current = Math.hypot(velocity.x, velocity.z);
                target = Math.min(Math.max(current, target * 0.85), target * 1.3);
            }
        }
        p.setVelocity(dx * target, velocity.y, dz * target);
    }
}
